class MyService {
    constructor() {

    }

    doSomething() {
        console.log("doesn't really do anything....");
    }
}

module.exports = MyService;