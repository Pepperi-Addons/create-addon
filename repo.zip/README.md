# @pepperi-addons 
Create a new pepperi addon.

## Installation
---
#### System Requirements
`node --version` > 12.0.0

`npm --version` > 6.0.0

#### Install by running 
``` bash
npm init @pepperi-addons
```
or 
``` bash
npx @pepperi-addons/create
```
